#include "pch.h"
#include "framework.h"
#include "SampleComCtlTest.h"
#include "SampleComCtlTestDlg.h"
#include "afxdialogex.h"
#include "..\DLLSample\MesaageViewer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



CSampleComCtlTestDlg::CSampleComCtlTestDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SAMPLECOMCTLTEST_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSampleComCtlTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSampleComCtlTestDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(IDOK, &CSampleComCtlTestDlg::OnBnClickedOk)
END_MESSAGE_MAP()


BOOL CSampleComCtlTestDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSampleComCtlTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    CDialogEx::OnSysCommand(nID, lParam);

}

void CSampleComCtlTestDlg::OnPaint()
{
    CPaintDC dc(this); 
    CDialogEx::OnPaint();
}

HCURSOR CSampleComCtlTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CSampleComCtlTestDlg::OnBnClickedOk()
{
    MesaageViewer SampleObject;
    SampleObject.Show();

    CDialogEx::OnOK();
}
