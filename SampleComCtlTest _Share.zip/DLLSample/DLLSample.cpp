// DLLSample.cpp : Defines the initialization routines for the DLL.
//

#include "pch.h"
#include "framework.h"
#include "DLLSample.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

BEGIN_MESSAGE_MAP(CDLLSampleApp, CWinApp)
END_MESSAGE_MAP()



CDLLSampleApp::CDLLSampleApp()
{

}


CDLLSampleApp theApp;



BOOL CDLLSampleApp::InitInstance()
{
	CWinApp::InitInstance();

	return TRUE;
}
