#include "pch.h"
#include "MessageBoxDlg.h"
#include "resource.h"

MessageBoxDlg::MessageBoxDlg(CWnd* pParent )
	: CDialog(IDD_DIALOGBAR, pParent)
{
}

void MessageBoxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(MessageBoxDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(IDC_BUTTON1, &MessageBoxDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


BOOL MessageBoxDlg::OnInitDialog()
{
	CDialog::OnInitDialog();


	return TRUE;  
}

void MessageBoxDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	CDialog::OnSysCommand(nID, lParam);
}

void MessageBoxDlg::OnPaint()
{

	CPaintDC dc(this); // device context for painting
	CDialog::OnPaint();

}

HCURSOR MessageBoxDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void MessageBoxDlg::OnBnClickedButton1()
{
   EndDialog(IDOK);
}
