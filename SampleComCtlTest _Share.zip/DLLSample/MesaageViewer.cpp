#include "pch.h"
#include "MesaageViewer.h"
#include "MessageBoxDlg.h"

void MesaageViewer::Show()
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());
    MessageBoxDlg DllDlg;
    DllDlg.DoModal();
}
