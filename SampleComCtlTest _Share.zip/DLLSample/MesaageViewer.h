#pragma once


#ifdef _MESSAGEVIWER_DLL_
#define _IMP_EXP_API_ __declspec(dllexport)
#else
#define _IMP_EXP_API_ __declspec(dllimport)
#endif

class _IMP_EXP_API_ MesaageViewer
{
public:

    MesaageViewer() = default;
    ~MesaageViewer() = default;
    void Show();

};

